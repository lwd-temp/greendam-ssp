﻿■开发环境
SSP最新版 + 最新HotFix + α
Windows 2000 SP4 
Visual C++ 6.0 Professional SP5


■最新版发布站
SSP BUGTRAQ
http://ssp.shillest.net/　ponapalt@shillest.net